import random
for i in range(5):
    print(random.randint(1, 10))